#import <Foundation/Foundation.h>
#import "SM_AFURLResponseSerialization.h"

@interface BinaryResponseSerializer : AFHTTPResponseSerializer

+ (instancetype)serializer;

@end
