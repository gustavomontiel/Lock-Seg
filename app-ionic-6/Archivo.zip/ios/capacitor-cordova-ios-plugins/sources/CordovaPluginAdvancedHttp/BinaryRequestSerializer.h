#import <Foundation/Foundation.h>
#import "SM_AFURLRequestSerialization.h"

@interface BinaryRequestSerializer : AFHTTPRequestSerializer

+ (instancetype)serializer;

@end
