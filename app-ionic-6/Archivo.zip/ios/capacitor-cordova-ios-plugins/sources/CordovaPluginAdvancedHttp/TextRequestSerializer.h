#import <Foundation/Foundation.h>
#import "SM_AFURLRequestSerialization.h"

@interface TextRequestSerializer : AFHTTPRequestSerializer

+ (instancetype)serializer;

@end
