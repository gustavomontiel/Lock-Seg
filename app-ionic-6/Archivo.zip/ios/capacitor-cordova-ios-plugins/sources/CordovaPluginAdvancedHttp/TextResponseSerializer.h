#import <Foundation/Foundation.h>
#import "SM_AFURLResponseSerialization.h"

@interface TextResponseSerializer : AFHTTPResponseSerializer

+ (instancetype)serializer;

@end
