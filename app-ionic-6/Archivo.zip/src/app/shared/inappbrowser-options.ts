export const inappbrowserOptionDefault = '';
export const inappbrowserOptionIos = 'location=no,toolbarcolor=#000000,footer=yes,footercolor=#000000,closebuttoncaption=Cerrar,hardwareback=yes';
export const inappbrowserOptionAndroid = 'location=yes,hideurlbar=yes,footer=no,toolbarcolor=#000000,hardwareback=yes,closebuttoncaption=Guazú Seguridad   -   Volver';
export const inappbrowserOptionSistem = '';
