export const environment = {
  production: true,
  APIEndpoint: 'https://api.guazuseguridad.com/',
};
